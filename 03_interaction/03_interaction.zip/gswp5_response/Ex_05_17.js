function setup() {
  createCanvas(120, 120);
  textSize(64);
  textAlign(CENTER);
}

function draw() {
  background(0);
  text(key, 60, 80);
}